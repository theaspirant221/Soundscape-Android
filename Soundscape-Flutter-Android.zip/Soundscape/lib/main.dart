import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'config.dart';
import 'screens/shell.dart';
import 'state/music_controller.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (AppConfig.hasSupabase) {
    await Supabase.initialize(
      url: AppConfig.supabaseUrl,
      anonKey: AppConfig.supabaseAnonKey,
    );
  }
  runApp(const SoundscapeApp());
}

class SoundscapeApp extends StatefulWidget {
  const SoundscapeApp({super.key});

  @override
  State<SoundscapeApp> createState() => _SoundscapeAppState();
}

class _SoundscapeAppState extends State<SoundscapeApp> {
  late final MusicController controller = MusicController();

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const accent = Color(0xFF7C5CFF);
    final scheme = ColorScheme.fromSeed(
      seedColor: accent,
      brightness: Brightness.dark,
      surface: const Color(0xFF111019),
    );
    return MaterialApp(
      title: 'Soundscape',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        colorScheme: scheme,
        scaffoldBackgroundColor: const Color(0xFF08070D),
        textTheme: GoogleFonts.outfitTextTheme(ThemeData.dark().textTheme),
        useMaterial3: true,
        snackBarTheme: const SnackBarThemeData(
          behavior: SnackBarBehavior.floating,
        ),
        navigationBarTheme: const NavigationBarThemeData(
          backgroundColor: Color(0xF2111019),
          indicatorColor: Color(0x447C5CFF),
        ),
      ),
      home: AppShell(controller: controller),
    );
  }
}

