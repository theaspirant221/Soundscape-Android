import 'dart:ui';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

import '../config.dart';
import '../models/track.dart';
import '../state/music_controller.dart';

class AppShell extends StatefulWidget {
  const AppShell({required this.controller, super.key});
  final MusicController controller;

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;
  final search = TextEditingController();

  MusicController get music => widget.controller;

  @override
  void dispose() {
    search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: music,
      builder: (context, _) => Scaffold(
        extendBody: true,
        body: Stack(
          children: [
            const _AmbientBackground(),
            SafeArea(
              bottom: false,
              child: IndexedStack(
                index: index,
                children: [
                  _home(),
                  _discover(),
                  _library(),
                  _profile(),
                ],
              ),
            ),
            if (music.current != null)
              Positioned(
                left: 14,
                right: 14,
                bottom: 82,
                child: _MiniPlayer(music: music, onOpen: _openPlayer),
              ),
          ],
        ),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (value) => setState(() => index = value),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_rounded), label: 'Home'),
            NavigationDestination(icon: Icon(Icons.travel_explore_rounded), label: 'Discover'),
            NavigationDestination(icon: Icon(Icons.library_music_rounded), label: 'Library'),
            NavigationDestination(icon: Icon(Icons.person_rounded), label: 'You'),
          ],
        ),
      ),
    );
  }

  Widget _page({required String eyebrow, required String title, required List<Widget> children}) {
    return CustomScrollView(
      slivers: [
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(20, 20, 20, 150),
          sliver: SliverList.list(
            children: [
              Text(eyebrow.toUpperCase(), style: const TextStyle(color: Color(0xFF9B87FF), letterSpacing: 2, fontWeight: FontWeight.w700, fontSize: 12)),
              const SizedBox(height: 6),
              Text(title, style: const TextStyle(fontSize: 32, fontWeight: FontWeight.w800, letterSpacing: -1)),
              const SizedBox(height: 24),
              ...children,
            ],
          ),
        ),
      ],
    );
  }

  Widget _home() => _page(
        eyebrow: 'Soundscape',
        title: 'Your music.\nNo noise.',
        children: [
          _GlassCard(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('LISTEN ON YOUR TERMS', style: TextStyle(color: Colors.white60, fontSize: 12, letterSpacing: 1.4)),
              const SizedBox(height: 10),
              const Text('Play music stored on your phone and discover official videos.', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, height: 1.2)),
              const SizedBox(height: 18),
              Wrap(spacing: 10, runSpacing: 10, children: [
                FilledButton.icon(onPressed: () => setState(() => index = 1), icon: const Icon(Icons.search), label: const Text('Discover')),
                OutlinedButton.icon(onPressed: music.loading ? null : music.scanLocal, icon: const Icon(Icons.folder_open), label: const Text('Scan phone')),
              ]),
            ]),
          ),
          if (music.error != null) ...[
            const SizedBox(height: 14),
            _notice(music.error!, Icons.error_outline, Colors.orangeAccent),
          ],
          const SizedBox(height: 28),
          _sectionTitle('Recently played', '${music.history.length} tracks'),
          const SizedBox(height: 12),
          if (music.history.isEmpty)
            _empty('Nothing played yet', 'Search YouTube or scan local audio to start.')
          else
            ...music.history.take(6).map(_trackTile),
        ],
      );

  Widget _discover() => _page(
        eyebrow: 'Explore',
        title: 'Find your next\nfavourite.',
        children: [
          TextField(
            controller: search,
            textInputAction: TextInputAction.search,
            onSubmitted: (value) {
              if (value.trim().isNotEmpty) music.search(value.trim());
            },
            decoration: InputDecoration(
              filled: true,
              fillColor: Colors.white.withValues(alpha: .07),
              hintText: 'Artists, songs, official videos',
              prefixIcon: const Icon(Icons.search_rounded),
              suffixIcon: IconButton(
                onPressed: () => music.search(search.text.trim()),
                icon: const Icon(Icons.arrow_forward_rounded),
              ),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(20), borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 12),
          if (!AppConfig.hasYouTube)
            _notice('Demo search is active. Add a YouTube Data API key for live results.', Icons.key_rounded, const Color(0xFF9B87FF)),
          const SizedBox(height: 20),
          if (music.loading) const Center(child: Padding(padding: EdgeInsets.all(40), child: CircularProgressIndicator())),
          ...music.searchResults.map(_trackTile),
        ],
      );

  Widget _library() => _page(
        eyebrow: 'Collection',
        title: 'Saved for you.',
        children: [
          Wrap(spacing: 10, runSpacing: 10, children: [
            _stat('${music.localTracks.length}', 'On device', Icons.phone_android),
            _stat('${music.favourites.length}', 'Favourites', Icons.favorite),
            _stat('${music.playlist.length}', 'Playlist', Icons.queue_music),
          ]),
          const SizedBox(height: 28),
          _sectionTitle('On this device', 'Scan again', action: music.scanLocal),
          const SizedBox(height: 10),
          if (music.localTracks.isEmpty)
            _empty('No local songs loaded', 'Tap Scan phone to give access and index your audio.')
          else
            ...music.localTracks.map(_trackTile),
          const SizedBox(height: 24),
          _sectionTitle('Favourites', '${music.favourites.length} tracks'),
          const SizedBox(height: 10),
          ...music.favourites.map(_trackTile),
        ],
      );

  Widget _profile() => _page(
        eyebrow: 'Account',
        title: 'Make it yours.',
        children: [
          _GlassCard(child: Row(children: [
            const CircleAvatar(radius: 30, backgroundColor: Color(0xFF7C5CFF), child: Icon(Icons.person, size: 34)),
            const SizedBox(width: 16),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(AppConfig.hasSupabase ? 'Cloud account ready' : 'Guest listener', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Text(AppConfig.hasSupabase ? 'Connect the auth screen to enable sync' : 'Add Supabase keys to enable login and sync', style: const TextStyle(color: Colors.white60)),
            ])),
          ])),
          const SizedBox(height: 18),
          _setting(Icons.timer_outlined, 'Sleep timer', music.sleepEndsAt == null ? 'Off' : 'Active', _showSleepTimer),
          _setting(Icons.graphic_eq_rounded, 'Equalizer', 'Android multi-band audio effect', _showEqualizer),
          _setting(Icons.download_done_rounded, 'Legal downloads', 'Direct licensed audio links only', _showDownloadInfo),
          _setting(Icons.cloud_outlined, 'Cloud account', music.cloud.user?.email ?? (AppConfig.hasSupabase ? 'Tap to sign in' : 'Needs Supabase keys'), _showCloudAccount),
          if (music.cloud.user != null) ...[
            _setting(Icons.cloud_upload_outlined, 'Upload library', 'Save favourites and playlist', music.pushCloud),
            _setting(Icons.cloud_download_outlined, 'Restore library', 'Replace local saved lists from cloud', music.pullCloud),
          ],
        ],
      );

  Widget _trackTile(Track track) => Padding(
        padding: const EdgeInsets.only(bottom: 9),
        child: _GlassCard(
          padding: const EdgeInsets.all(9),
          child: Row(children: [
            _art(track, 56),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(track.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 4),
              Text(track.artist, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white54, fontSize: 13)),
            ])),
            IconButton(
              onPressed: () => track.source == TrackSource.youtube ? _playYouTube(track) : music.playAudio(track),
              icon: Icon(track.source == TrackSource.youtube ? Icons.smart_display_rounded : Icons.play_arrow_rounded),
            ),
            PopupMenuButton<String>(
              onSelected: (value) {
                if (value == 'fav') music.toggleFavourite(track);
                if (value == 'list') music.addToPlaylist(track);
                if (value == 'lyrics') _showLyrics(track);
              },
              itemBuilder: (_) => [
                PopupMenuItem(value: 'fav', child: Text(music.isFavourite(track) ? 'Remove favourite' : 'Add favourite')),
                const PopupMenuItem(value: 'list', child: Text('Add to playlist')),
                const PopupMenuItem(value: 'lyrics', child: Text('Find lyrics')),
              ],
            ),
          ]),
        ),
      );

  Widget _art(Track track, double size) => ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: track.artworkUrl == null
            ? Container(width: size, height: size, color: const Color(0xFF29243D), child: const Icon(Icons.music_note_rounded))
            : CachedNetworkImage(imageUrl: track.artworkUrl!, width: size, height: size, fit: BoxFit.cover, errorWidget: (_, __, ___) => const Icon(Icons.music_note)),
      );

  Widget _sectionTitle(String title, String side, {VoidCallback? action}) => Row(children: [
        Expanded(child: Text(title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w700))),
        TextButton(onPressed: action, child: Text(side)),
      ]);

  Widget _empty(String title, String body) => _GlassCard(child: Column(children: [
        const Icon(Icons.album_outlined, size: 40, color: Colors.white38),
        const SizedBox(height: 10),
        Text(title, style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 4),
        Text(body, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white54)),
      ]));

  Widget _notice(String text, IconData icon, Color color) => Container(
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(color: color.withValues(alpha: .12), border: Border.all(color: color.withValues(alpha: .3)), borderRadius: BorderRadius.circular(16)),
        child: Row(children: [Icon(icon, color: color), const SizedBox(width: 10), Expanded(child: Text(text, style: const TextStyle(fontSize: 13)))]),
      );

  Widget _stat(String value, String label, IconData icon) => Container(
        width: (MediaQuery.sizeOf(context).width - 60) / 3,
        padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 8),
        decoration: BoxDecoration(color: Colors.white.withValues(alpha: .06), borderRadius: BorderRadius.circular(18), border: Border.all(color: Colors.white10)),
        child: Column(children: [Icon(icon, color: const Color(0xFF9B87FF)), const SizedBox(height: 7), Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), Text(label, style: const TextStyle(fontSize: 11, color: Colors.white54))]),
      );

  Widget _setting(IconData icon, String title, String subtitle, VoidCallback onTap) => ListTile(
        onTap: onTap,
        leading: CircleAvatar(backgroundColor: Colors.white10, child: Icon(icon, color: const Color(0xFFB7A8FF))),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_right_rounded),
      );

  void _playYouTube(Track track) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => YouTubeNowPlaying(track: track)));
  }

  void _openPlayer() {
    showModalBottomSheet(context: context, isScrollControlled: true, backgroundColor: Colors.transparent, builder: (_) => _NowPlayingSheet(music: music));
  }

  Future<void> _showLyrics(Track track) async {
    showModalBottomSheet(context: context, isScrollControlled: true, builder: (sheetContext) => FutureBuilder<String>(
      future: music.lyricsService.find(track.title, track.artist),
      builder: (_, snap) => DraggableScrollableSheet(expand: false, initialChildSize: .75, builder: (_, controller) => Padding(
        padding: const EdgeInsets.all(24),
        child: ListView(controller: controller, children: [Text(track.title, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold)), const SizedBox(height: 20), if (!snap.hasData) const Center(child: CircularProgressIndicator()) else Text(snap.data!, style: const TextStyle(fontSize: 17, height: 1.65))]),
      )),
    ));
  }

  void _showSleepTimer() => showModalBottomSheet(context: context, builder: (_) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: [
    const ListTile(title: Text('Sleep timer', style: TextStyle(fontWeight: FontWeight.bold))),
    for (final minutes in [15, 30, 45, 60]) ListTile(title: Text('$minutes minutes'), onTap: () { music.startSleepTimer(Duration(minutes: minutes)); Navigator.pop(context); }),
    if (music.sleepEndsAt != null) ListTile(title: const Text('Cancel timer'), textColor: Colors.redAccent, onTap: () { music.cancelSleepTimer(); Navigator.pop(context); }),
  ])));

  void _showEqualizer() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => FutureBuilder<dynamic>(
        future: music.enableEqualizer(),
        builder: (sheetContext, snapshot) {
          if (snapshot.hasError) {
            return SafeArea(child: Padding(padding: const EdgeInsets.all(24), child: Text('This device did not expose an Android equalizer: ${snapshot.error}')));
          }
          if (!snapshot.hasData) return const SafeArea(child: SizedBox(height: 220, child: Center(child: CircularProgressIndicator())));
          final dynamic parameters = snapshot.data;
          final List<dynamic> bands = List<dynamic>.from(parameters.bands as List);
          return StatefulBuilder(builder: (context, refresh) => SafeArea(child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Row(children: [const Expanded(child: Text('Equalizer', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold))), TextButton(onPressed: () async { await music.disableEqualizer(); if (sheetContext.mounted) Navigator.pop(sheetContext); }, child: const Text('Disable'))]),
              const SizedBox(height: 18),
              SizedBox(height: 260, child: Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                for (final dynamic band in bands)
                  Expanded(child: Column(children: [
                    Expanded(child: RotatedBox(quarterTurns: 3, child: Slider(
                      min: (parameters.minDecibels as num).toDouble(),
                      max: (parameters.maxDecibels as num).toDouble(),
                      value: (band.gain as num).toDouble().clamp((parameters.minDecibels as num).toDouble(), (parameters.maxDecibels as num).toDouble()).toDouble(),
                      onChanged: (value) async { await band.setGain(value); refresh(() {}); },
                    ))),
                    Text(_frequency((band.centerFrequency as num).toDouble()), style: const TextStyle(fontSize: 11, color: Colors.white60)),
                  ])),
              ])),
            ]),
          )));
        },
      ),
    );
  }
  String _frequency(double hertz) => hertz >= 1000 ? '${(hertz / 1000).toStringAsFixed(hertz >= 10000 ? 0 : 1)}k' : hertz.toStringAsFixed(0);
  void _showDownloadInfo() => _message('Legal downloads only', 'The download service accepts direct audio URLs only when the publisher permits downloading. It deliberately does not extract or convert YouTube streams.');
  void _showCloudAccount() {
    if (!AppConfig.hasSupabase) {
      _message('Cloud sync', 'Add SUPABASE_URL and SUPABASE_ANON_KEY as dart-defines. Never put a service-role key inside the app.');
      return;
    }
    if (music.cloud.user != null) {
      showDialog(context: context, builder: (_) => AlertDialog(title: Text(music.cloud.user!.email ?? 'Signed in'), content: const Text('Your favourites and playlist can now be uploaded or restored.'), actions: [TextButton(onPressed: () async { await music.signOut(); if (context.mounted) Navigator.pop(context); }, child: const Text('Sign out')), TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))]));
      return;
    }
    final email = TextEditingController();
    final password = TextEditingController();
    showDialog(context: context, builder: (dialogContext) => AlertDialog(
      title: const Text('Cloud account'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email')), const SizedBox(height: 10), TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password'))]),
      actions: [
        TextButton(onPressed: () async { await music.signUp(email.text.trim(), password.text); if (dialogContext.mounted) Navigator.pop(dialogContext); }, child: const Text('Create account')),
        FilledButton(onPressed: () async { await music.signIn(email.text.trim(), password.text); if (dialogContext.mounted) Navigator.pop(dialogContext); }, child: const Text('Sign in')),
      ],
    ));
  }
  void _message(String title, String body) => showDialog(context: context, builder: (_) => AlertDialog(title: Text(title), content: Text(body), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Got it'))]));
}

class _GlassCard extends StatelessWidget {
  const _GlassCard({required this.child, this.padding = const EdgeInsets.all(20)});
  final Widget child;
  final EdgeInsets padding;
  @override
  Widget build(BuildContext context) => ClipRRect(
    borderRadius: BorderRadius.circular(22),
    child: BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
      child: Container(padding: padding, decoration: BoxDecoration(color: Colors.white.withValues(alpha: .065), borderRadius: BorderRadius.circular(22), border: Border.all(color: Colors.white.withValues(alpha: .1))), child: child),
    ),
  );
}

class _AmbientBackground extends StatelessWidget {
  const _AmbientBackground();
  @override
  Widget build(BuildContext context) => Stack(children: [
    Positioned(top: -120, right: -100, child: Container(width: 330, height: 330, decoration: const BoxDecoration(shape: BoxShape.circle, gradient: RadialGradient(colors: [Color(0x557C5CFF), Colors.transparent])))),
    Positioned(top: 350, left: -140, child: Container(width: 300, height: 300, decoration: const BoxDecoration(shape: BoxShape.circle, gradient: RadialGradient(colors: [Color(0x3344D7B6), Colors.transparent])))),
  ]);
}

class _MiniPlayer extends StatelessWidget {
  const _MiniPlayer({required this.music, required this.onOpen});
  final MusicController music;
  final VoidCallback onOpen;
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onOpen,
    child: _GlassCard(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9), child: Row(children: [
      const CircleAvatar(backgroundColor: Color(0xFF332C50), child: Icon(Icons.music_note)),
      const SizedBox(width: 10),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(music.current!.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)), Text(music.current!.artist, maxLines: 1, style: const TextStyle(color: Colors.white54, fontSize: 12))])),
      IconButton(onPressed: music.togglePlay, icon: Icon(music.playing ? Icons.pause_rounded : Icons.play_arrow_rounded)),
    ])),
  );
}

class _NowPlayingSheet extends StatelessWidget {
  const _NowPlayingSheet({required this.music});
  final MusicController music;
  @override
  Widget build(BuildContext context) {
    final track = music.current!;
    final max = music.duration.inMilliseconds.toDouble().clamp(1, double.infinity).toDouble();
    final value = music.position.inMilliseconds.toDouble().clamp(0, max).toDouble();
    return Container(
      height: MediaQuery.sizeOf(context).height * .78,
      padding: const EdgeInsets.fromLTRB(26, 14, 26, 30),
      decoration: const BoxDecoration(color: Color(0xFF14121E), borderRadius: BorderRadius.vertical(top: Radius.circular(32))),
      child: Column(children: [
        Container(width: 42, height: 4, decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(9))),
        const Spacer(),
        Container(width: 260, height: 260, decoration: BoxDecoration(borderRadius: BorderRadius.circular(36), gradient: const LinearGradient(colors: [Color(0xFF7C5CFF), Color(0xFF27213B)]), boxShadow: const [BoxShadow(color: Color(0x557C5CFF), blurRadius: 45)]), child: const Icon(Icons.graphic_eq_rounded, size: 92)),
        const Spacer(),
        Text(track.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800)),
        const SizedBox(height: 5),
        Text(track.artist, style: const TextStyle(color: Colors.white54, fontSize: 16)),
        const SizedBox(height: 22),
        Slider(value: value, max: max, onChanged: (ms) => music.seek(Duration(milliseconds: ms.round()))),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text(_time(music.position)), Text(_time(music.duration))]),
        const SizedBox(height: 8),
        Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          IconButton(onPressed: () => music.seek(music.position - const Duration(seconds: 10)), icon: const Icon(Icons.replay_10_rounded, size: 34)),
          FilledButton(onPressed: music.togglePlay, style: FilledButton.styleFrom(shape: const CircleBorder(), padding: const EdgeInsets.all(20)), child: Icon(music.playing ? Icons.pause_rounded : Icons.play_arrow_rounded, size: 38)),
          IconButton(onPressed: () => music.seek(music.position + const Duration(seconds: 10)), icon: const Icon(Icons.forward_10_rounded, size: 34)),
        ]),
      ]),
    );
  }
  static String _time(Duration value) => '${value.inMinutes}:${(value.inSeconds % 60).toString().padLeft(2, '0')}';
}

class YouTubeNowPlaying extends StatefulWidget {
  const YouTubeNowPlaying({required this.track, super.key});
  final Track track;
  @override
  State<YouTubeNowPlaying> createState() => _YouTubeNowPlayingState();
}

class _YouTubeNowPlayingState extends State<YouTubeNowPlaying> {
  late final YoutubePlayerController controller = YoutubePlayerController(
    initialVideoId: widget.track.id,
    flags: const YoutubePlayerFlags(autoPlay: true, enableCaption: true),
  );
  @override
  void dispose() { controller.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => YoutubePlayerBuilder(
    player: YoutubePlayer(controller: controller, showVideoProgressIndicator: true),
    builder: (_, player) => Scaffold(appBar: AppBar(title: const Text('Official playback')), body: ListView(padding: const EdgeInsets.all(18), children: [player, const SizedBox(height: 20), Text(widget.track.title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.bold)), const SizedBox(height: 6), Text(widget.track.artist, style: const TextStyle(color: Colors.white60)), const SizedBox(height: 24), const Text('Playback uses the permitted embedded YouTube player. Downloads and audio extraction are intentionally unavailable.', style: TextStyle(color: Colors.white54, height: 1.5))])),
  );
}
