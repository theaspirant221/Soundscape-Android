import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:just_audio/just_audio.dart';

import '../models/track.dart';
import '../services/music_services.dart';
import '../services/cloud_service.dart';

class MusicController extends ChangeNotifier {
  MusicController() {
    _player.playerStateStream.listen((_) => notifyListeners());
    _player.positionStream.listen((_) => notifyListeners());
    _loadSaved();
  }

  final AndroidEqualizer equalizer = AndroidEqualizer();
  late final AudioPlayer _player = AudioPlayer(
    audioPipeline: AudioPipeline(androidAudioEffects: [equalizer]),
  );
  final LibraryStore _store = LibraryStore();
  final LocalMusicService localService = LocalMusicService();
  final YouTubeDiscoveryService youtubeService = YouTubeDiscoveryService();
  final LyricsService lyricsService = LyricsService();
  final LegalDownloadService downloadService = LegalDownloadService();
  final CloudService cloud = CloudService();

  List<Track> localTracks = [];
  List<Track> searchResults = [];
  List<Track> favourites = [];
  List<Track> history = [];
  List<Track> playlist = [];
  Track? current;
  bool loading = false;
  String? error;
  Timer? _sleepTimer;
  DateTime? sleepEndsAt;

  AudioPlayer get player => _player;
  bool get playing => _player.playing;
  Duration get position => _player.position;
  Duration get duration => _player.duration ?? Duration.zero;
  bool isFavourite(Track track) => favourites.any((item) => item.id == track.id);

  Future<void> _loadSaved() async {
    favourites = await _store.favourites();
    history = await _store.history();
    playlist = await _store.playlist();
    notifyListeners();
  }

  Future<void> scanLocal() async => _guard(() async {
        localTracks = await localService.scan();
      });

  Future<void> search(String query) async => _guard(() async {
        searchResults = await youtubeService.search(query);
      });

  Future<void> playAudio(Track track) async {
    if (!track.canPlayAsAudio) return;
    try {
      if (track.localUri != null) {
        await _player.setAudioSource(AudioSource.uri(Uri.parse(track.localUri!)));
      } else if (track.audioUrl != null) {
        await _player.setUrl(track.audioUrl!);
      } else {
        throw Exception('No playable audio source');
      }
      current = track;
      history.removeWhere((item) => item.id == track.id);
      history.insert(0, track);
      if (history.length > 50) history = history.take(50).toList();
      await _store.saveHistory(history);
      await _player.play();
      notifyListeners();
    } catch (exception) {
      error = exception.toString();
      notifyListeners();
    }
  }

  Future<void> togglePlay() => playing ? _player.pause() : _player.play();
  Future<void> seek(Duration value) => _player.seek(value);

  Future<dynamic> enableEqualizer() async {
    await equalizer.setEnabled(true);
    return equalizer.parameters;
  }

  Future<void> disableEqualizer() => equalizer.setEnabled(false);

  Future<void> toggleFavourite(Track track) async {
    if (isFavourite(track)) {
      favourites.removeWhere((item) => item.id == track.id);
    } else {
      favourites.insert(0, track);
    }
    await _store.saveFavourites(favourites);
    notifyListeners();
  }

  Future<void> addToPlaylist(Track track) async {
    if (!playlist.any((item) => item.id == track.id)) playlist.add(track);
    await _store.savePlaylist(playlist);
    notifyListeners();
  }

  Future<void> signIn(String email, String password) async => _guard(() async {
        await cloud.signIn(email, password);
      });

  Future<void> signUp(String email, String password) async => _guard(() async {
        await cloud.signUp(email, password);
      });

  Future<void> signOut() async => _guard(cloud.signOut);

  Future<void> pushCloud() async => _guard(() async {
        await cloud.push(favourites: favourites, playlist: playlist);
      });

  Future<void> pullCloud() async => _guard(() async {
        final data = await cloud.pull();
        favourites = data.favourites;
        playlist = data.playlist;
        await _store.saveFavourites(favourites);
        await _store.savePlaylist(playlist);
      });

  void startSleepTimer(Duration duration) {
    _sleepTimer?.cancel();
    sleepEndsAt = DateTime.now().add(duration);
    _sleepTimer = Timer(duration, () async {
      await _player.pause();
      sleepEndsAt = null;
      notifyListeners();
    });
    notifyListeners();
  }

  void cancelSleepTimer() {
    _sleepTimer?.cancel();
    sleepEndsAt = null;
    notifyListeners();
  }

  Future<void> _guard(Future<void> Function() action) async {
    loading = true;
    error = null;
    notifyListeners();
    try {
      await action();
    } catch (exception) {
      error = exception.toString().replaceFirst('Exception: ', '');
    } finally {
      loading = false;
      notifyListeners();
    }
  }

  @override
  void dispose() {
    _sleepTimer?.cancel();
    _player.dispose();
    super.dispose();
  }
}
