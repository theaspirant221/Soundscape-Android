class AppConfig {
  // Add keys here for local testing. For a public release, inject them at
  // build time with --dart-define and restrict the Google key to your app.
  static const youtubeApiKey = String.fromEnvironment('YOUTUBE_API_KEY');
  static const supabaseUrl = String.fromEnvironment('SUPABASE_URL');
  static const supabaseAnonKey = String.fromEnvironment('SUPABASE_ANON_KEY');

  static bool get hasYouTube => youtubeApiKey.isNotEmpty;
  static bool get hasSupabase =>
      supabaseUrl.isNotEmpty && supabaseAnonKey.isNotEmpty;
}

