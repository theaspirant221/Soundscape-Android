import 'package:supabase_flutter/supabase_flutter.dart';

import '../config.dart';
import '../models/track.dart';

class CloudService {
  bool get available => AppConfig.hasSupabase;
  SupabaseClient get _client => Supabase.instance.client;
  User? get user => available ? _client.auth.currentUser : null;

  Future<void> signUp(String email, String password) async {
    if (!available) throw Exception('Supabase is not configured');
    await _client.auth.signUp(email: email, password: password);
  }

  Future<void> signIn(String email, String password) async {
    if (!available) throw Exception('Supabase is not configured');
    await _client.auth.signInWithPassword(email: email, password: password);
  }

  Future<void> signOut() async {
    if (available) await _client.auth.signOut();
  }

  Future<void> push({required List<Track> favourites, required List<Track> playlist}) async {
    final id = user?.id;
    if (id == null) throw Exception('Sign in before syncing');
    await _client.from('user_libraries').upsert({
      'user_id': id,
      'favourites': favourites.map((track) => track.toJson()).toList(),
      'playlist': playlist.map((track) => track.toJson()).toList(),
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    });
  }

  Future<({List<Track> favourites, List<Track> playlist})> pull() async {
    final id = user?.id;
    if (id == null) throw Exception('Sign in before syncing');
    final row = await _client.from('user_libraries').select().eq('user_id', id).maybeSingle();
    if (row == null) return (favourites: <Track>[], playlist: <Track>[]);
    List<Track> decode(dynamic raw) => ((raw as List<dynamic>?) ?? const [])
        .map((item) => Track.fromJson(Map<String, dynamic>.from(item as Map)))
        .toList();
    return (favourites: decode(row['favourites']), playlist: decode(row['playlist']));
  }
}

