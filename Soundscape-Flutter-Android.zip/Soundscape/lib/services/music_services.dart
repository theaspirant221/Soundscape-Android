import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:http/http.dart' as http;
import 'package:on_audio_query/on_audio_query.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../config.dart';
import '../models/track.dart';

class YouTubeDiscoveryService {
  Future<List<Track>> search(String query) async {
    if (!AppConfig.hasYouTube) return demoResults(query);
    final uri = Uri.https('www.googleapis.com', '/youtube/v3/search', {
      'part': 'snippet',
      'type': 'video',
      'videoCategoryId': '10',
      'maxResults': '20',
      'q': query,
      'key': AppConfig.youtubeApiKey,
    });
    final response = await http.get(uri);
    if (response.statusCode != 200) {
      throw Exception('YouTube search failed (${response.statusCode})');
    }
    final body = jsonDecode(response.body) as Map<String, dynamic>;
    return (body['items'] as List<dynamic>).map((raw) {
      final item = raw as Map<String, dynamic>;
      final id = (item['id'] as Map<String, dynamic>)['videoId'] as String;
      final snippet = item['snippet'] as Map<String, dynamic>;
      final thumbs = snippet['thumbnails'] as Map<String, dynamic>;
      final thumb = (thumbs['high'] ?? thumbs['medium'] ?? thumbs['default'])
          as Map<String, dynamic>;
      return Track(
        id: id,
        title: _decode(snippet['title'] as String),
        artist: _decode(snippet['channelTitle'] as String),
        artworkUrl: thumb['url'] as String?,
        source: TrackSource.youtube,
      );
    }).toList();
  }

  String _decode(String value) => value
      .replaceAll('&amp;', '&')
      .replaceAll('&#39;', "'")
      .replaceAll('&quot;', '"');

  List<Track> demoResults(String query) => [
        Track(
          id: 'jfKfPfyJRdk',
          title: query.isEmpty ? 'Lofi hip hop radio' : '$query — demo result',
          artist: 'YouTube discovery demo',
          artworkUrl: 'https://i.ytimg.com/vi/jfKfPfyJRdk/hqdefault.jpg',
          source: TrackSource.youtube,
        ),
      ];
}

class LocalMusicService {
  final OnAudioQuery _query = OnAudioQuery();

  Future<List<Track>> scan() async {
    var granted = await Permission.audio.isGranted;
    if (!granted) granted = (await Permission.audio.request()).isGranted;
    if (!granted && Platform.isAndroid) {
      granted = (await Permission.storage.request()).isGranted;
    }
    if (!granted) throw Exception('Audio permission was denied');
    final songs = await _query.querySongs(
      sortType: SongSortType.TITLE,
      orderType: OrderType.ASC_OR_SMALLER,
      uriType: UriType.EXTERNAL,
      ignoreCase: true,
    );
    return songs
        .where((song) => (song.duration ?? 0) > 15000 && song.uri != null)
        .map((song) => Track(
              id: 'local_${song.id}',
              title: song.title,
              artist: song.artist ?? 'Unknown artist',
              album: song.album ?? 'Unknown album',
              localUri: song.uri,
              durationMs: song.duration ?? 0,
              source: TrackSource.local,
            ))
        .toList();
  }
}

class LibraryStore {
  static const _favouritesKey = 'favourites_v1';
  static const _historyKey = 'history_v1';
  static const _playlistKey = 'playlist_liked_v1';

  Future<List<Track>> load(String key) async {
    final prefs = await SharedPreferences.getInstance();
    final values = prefs.getStringList(key) ?? const [];
    return values
        .map((value) => Track.fromJson(jsonDecode(value) as Map<String, dynamic>))
        .toList();
  }

  Future<void> save(String key, List<Track> tracks) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setStringList(
      key,
      tracks.map((track) => jsonEncode(track.toJson())).toList(),
    );
  }

  Future<List<Track>> favourites() => load(_favouritesKey);
  Future<List<Track>> history() => load(_historyKey);
  Future<List<Track>> playlist() => load(_playlistKey);
  Future<void> saveFavourites(List<Track> value) => save(_favouritesKey, value);
  Future<void> saveHistory(List<Track> value) => save(_historyKey, value);
  Future<void> savePlaylist(List<Track> value) => save(_playlistKey, value);
}

class LyricsService {
  Future<String> find(String title, String artist) async {
    final uri = Uri.https('lrclib.net', '/api/search', {
      'track_name': title,
      'artist_name': artist,
    });
    final response = await http.get(uri, headers: {'User-Agent': 'Soundscape/1.0'});
    if (response.statusCode != 200) throw Exception('Lyrics unavailable');
    final results = jsonDecode(response.body) as List<dynamic>;
    if (results.isEmpty) return 'No lyrics found for this track.';
    final result = results.first as Map<String, dynamic>;
    return (result['plainLyrics'] ?? result['syncedLyrics'] ??
            'No lyrics found for this track.')
        as String;
  }
}

class LegalDownloadService {
  Future<File> download(Track track, void Function(double) onProgress) async {
    if (track.source != TrackSource.legalUrl || track.audioUrl == null) {
      throw ArgumentError('Only permitted direct audio URLs can be downloaded.');
    }
    final root = await getApplicationDocumentsDirectory();
    final folder = Directory('${root.path}/Soundscape');
    await folder.create(recursive: true);
    final safeName = track.title.replaceAll(RegExp(r'[^a-zA-Z0-9 _-]'), '').trim();
    final file = File('${folder.path}/${safeName.isEmpty ? track.id : safeName}.mp3');
    await Dio().download(
      track.audioUrl!,
      file.path,
      onReceiveProgress: (received, total) {
        if (total > 0) onProgress(received / total);
      },
    );
    return file;
  }
}

