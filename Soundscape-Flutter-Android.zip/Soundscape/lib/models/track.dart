enum TrackSource { local, youtube, legalUrl }

class Track {
  const Track({
    required this.id,
    required this.title,
    required this.artist,
    required this.source,
    this.album = 'Unknown album',
    this.artworkUrl,
    this.audioUrl,
    this.localUri,
    this.durationMs = 0,
  });

  final String id;
  final String title;
  final String artist;
  final String album;
  final TrackSource source;
  final String? artworkUrl;
  final String? audioUrl;
  final String? localUri;
  final int durationMs;

  bool get canPlayAsAudio => source != TrackSource.youtube;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'artist': artist,
        'album': album,
        'source': source.name,
        'artworkUrl': artworkUrl,
        'audioUrl': audioUrl,
        'localUri': localUri,
        'durationMs': durationMs,
      };

  factory Track.fromJson(Map<String, dynamic> json) => Track(
        id: json['id'] as String,
        title: json['title'] as String,
        artist: (json['artist'] as String?) ?? 'Unknown artist',
        album: (json['album'] as String?) ?? 'Unknown album',
        source: TrackSource.values.firstWhere(
          (value) => value.name == json['source'],
          orElse: () => TrackSource.legalUrl,
        ),
        artworkUrl: json['artworkUrl'] as String?,
        audioUrl: json['audioUrl'] as String?,
        localUri: json['localUri'] as String?,
        durationMs: (json['durationMs'] as num?)?.toInt() ?? 0,
      );
}

