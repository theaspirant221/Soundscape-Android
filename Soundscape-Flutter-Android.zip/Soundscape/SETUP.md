# Setup guide

## 1. Generate Android platform files

Run this once from the project folder:

```bash
flutter create --platforms=android --org com.builtby3 .
```

The command generates standard Android runner files and preserves `lib/` and `pubspec.yaml`.

## 2. Android permissions

Open `android/app/src/main/AndroidManifest.xml`. Add these directly inside `<manifest>` and above `<application>`:

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.READ_MEDIA_AUDIO" />
<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32" />
```

Set the app label on `<application>` to `android:label="Soundscape"`.

## 3. Live YouTube discovery

1. In Google Cloud Console, create a project.
2. Enable **YouTube Data API v3**.
3. Create an Android/API key and restrict it before release.
4. Pass the value with `--dart-define=YOUTUBE_API_KEY=...`.

Search uses the official Data API. Playback stays inside the official YouTube embedded player. The app never converts or downloads those streams.

## 4. Login and cloud sync

Create a Supabase project, enable Email authentication, then run this SQL in its SQL editor:

```sql
create table public.user_libraries (
  user_id uuid primary key references auth.users(id) on delete cascade,
  favourites jsonb not null default '[]'::jsonb,
  playlist jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.user_libraries enable row level security;

create policy "Users read own library"
on public.user_libraries for select
using (auth.uid() = user_id);

create policy "Users insert own library"
on public.user_libraries for insert
with check (auth.uid() = user_id);

create policy "Users update own library"
on public.user_libraries for update
using (auth.uid() = user_id)
with check (auth.uid() = user_id);
```

Pass the public project values at run/build time:

```bash
flutter run \
  --dart-define=SUPABASE_URL=https://YOUR_PROJECT.supabase.co \
  --dart-define=SUPABASE_ANON_KEY=YOUR_PUBLIC_ANON_KEY
```

Do not put the Supabase service-role key in a mobile app.

## 5. Legal download sources

`LegalDownloadService` only accepts `TrackSource.legalUrl` with a direct `audioUrl`. Add tracks only when you own the audio, it is public domain/Creative Commons with download permission, or the publisher explicitly provides a downloadable URL. Attribution requirements still apply.

## 6. Before calling it production-ready

- Test Android 10 through the newest supported Android release.
- Add audio-focus handling and foreground media notification controls.
- Replace the simple single playlist with playlist CRUD if needed.
- Verify every content provider's terms and privacy requirements.
- Add privacy policy, account deletion, error telemetry, and release signing.
- Test Supabase email confirmation and password reset flows.
- Obtain permission before displaying or redistributing lyrics.

