# Soundscape

Soundscape is a dark glass-style Flutter music player built around legal playback:

- local Android audio scanning and playback;
- YouTube Data API search with playback through the official embedded player;
- favourites, listening history, and a playlist stored offline;
- email login and cloud backup through Supabase;
- lyrics search through LRCLIB;
- sleep timer and Android multi-band equalizer;
- direct-file downloads only for audio the publisher explicitly allows to be downloaded.

It does **not** extract YouTube audio, remove ads, bypass Premium, or download copyrighted YouTube media.

## Fast start

1. Install Flutter and Android Studio.
2. Open a terminal in this folder.
3. Run `flutter create --platforms=android --org com.builtby3 .`
4. Apply the Android permission additions shown in `SETUP.md`.
5. Run `flutter pub get`.
6. Connect your Android phone with USB debugging enabled.
7. Run `flutter run`.

Without API keys, local playback works and YouTube discovery displays a demo result. See `SETUP.md` for live search and cloud sync.

## Build an installable APK

```bash
flutter build apk --release \
  --dart-define=YOUTUBE_API_KEY=YOUR_KEY \
  --dart-define=SUPABASE_URL=YOUR_URL \
  --dart-define=SUPABASE_ANON_KEY=YOUR_ANON_KEY
```

The APK will be at `build/app/outputs/flutter-apk/app-release.apk`.

## Build without installing Flutter

Push this project to GitHub. The included **Build Android APK** workflow runs automatically on `main`, or manually from the repository's **Actions** tab. When it succeeds, download the `Soundscape-Android-APK` artifact and install `app-release.apk` on your phone.

## Honest project status

The source is implementation-ready, but an APK was not compiled in the creation environment because Flutter/Android SDKs were unavailable there. Device-specific media permissions, equalizer support, notification controls, and Play Store policy compliance must be tested on real Android versions before release.
