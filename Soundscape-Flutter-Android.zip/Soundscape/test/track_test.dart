import 'package:flutter_test/flutter_test.dart';
import 'package:soundscape/models/track.dart';

void main() {
  test('track survives local serialization', () {
    const original = Track(
      id: '42',
      title: 'Test track',
      artist: 'Soundscape',
      source: TrackSource.local,
      localUri: 'content://audio/42',
      durationMs: 123000,
    );

    final restored = Track.fromJson(original.toJson());

    expect(restored.id, original.id);
    expect(restored.source, TrackSource.local);
    expect(restored.localUri, original.localUri);
    expect(restored.durationMs, 123000);
  });
}

