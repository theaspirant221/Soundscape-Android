#!/usr/bin/env bash
set -euo pipefail

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter is not installed. Install it from https://docs.flutter.dev/get-started/install"
  exit 1
fi

flutter create --platforms=android --org com.builtby3 .
flutter pub get
flutter analyze

echo "Android files created. Add the permissions from SETUP.md, then run: flutter run"

